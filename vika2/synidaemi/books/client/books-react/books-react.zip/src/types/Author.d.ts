interface AuthorEntity {
    _id: string;
    name: string;
    birthdate: Date;
    description: string;
    image: string;
}
