export const BASE_API_URL = 'http://localhost:4000';
export const BOOKS_URL = `${BASE_API_URL}/books`;
export const AUTHORS_URL = `${BASE_API_URL}/authors`;
